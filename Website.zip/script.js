const opening = document.getElementById("opening");
const enterBtn = document.getElementById("enterBtn");

const wishBtn = document.getElementById("wishBtn");
const wishText = document.getElementById("wishText");

const flame = document.getElementById("flame");

const celebrateBtn = document.getElementById("celebrateBtn");


// =================================
// ENTER WEBSITE
// =================================

enterBtn.addEventListener("click", () => {


    opening.classList.add("hide");

});


// =================================
// MAKE A WISH
// =================================

wishBtn.addEventListener("click", () => {

    flame.style.opacity = "0";

    wishText.innerHTML =
        "✨ Semoga harapan yang kamu simpan malam ini perlahan menjadi kenyataan. ✨";

    wishText.classList.add("show");

    createParticles();

});


// =================================
// CELEBRATE
// =================================

celebrateBtn.addEventListener("click", () => {

    createParticles();

    createParticles();

});


// =================================
// PARTICLES
// =================================

function createParticles() {

    const emojis = [
        "🎃",
        "👻",
        "🦇",
        "🕸️",
        "✨",
        "🕯️",
        "🖤"
    ];

    for (let i = 0; i < 35; i++) {

        const particle = document.createElement("div");

        particle.innerHTML =
            emojis[Math.floor(Math.random() * emojis.length)];

        particle.style.position = "fixed";

        particle.style.left =
            Math.random() * 100 + "vw";

        particle.style.top = "-50px";

        particle.style.fontSize =
            Math.random() * 20 + 15 + "px";

        particle.style.zIndex = "99999";

        particle.style.pointerEvents = "none";

        document.body.appendChild(particle);


        const duration =
            Math.random() * 3 + 2;


        particle.animate(

            [
                {
                    transform: "translateY(0) rotate(0deg)",
                    opacity: 1
                },

                {
                    transform:
                        `translateY(110vh)
                         rotate(${Math.random() * 720}deg)`,

                    opacity: 0
                }

            ],

            {
                duration: duration * 1000,
                easing: "linear"
            }

        );


        setTimeout(() => {

            particle.remove();

        }, duration * 1000);

    }

}